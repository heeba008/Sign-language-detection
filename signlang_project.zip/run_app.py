import argparse, json, time
from collections import deque
from pathlib import Path

import cv2
import numpy as np
import joblib
import mediapipe as mp
import pyttsx3

from utils import normalize_landmarks, majority_vote

def extract_landmarks(results):
    if not results.multi_hand_landmarks:
        return None
    hand_landmarks = results.multi_hand_landmarks[0]
    lm = []
    for lm_pt in hand_landmarks.landmark:
        lm.append([lm_pt.x, lm_pt.y, lm_pt.z])
    return np.array(lm, dtype=np.float32)  # (21,3)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--camera-index", type=int, default=0)
    ap.add_argument("--smoothing", type=int, default=6, help="Window for majority vote")
    ap.add_argument("--speak-interval", type=float, default=1.2, help="Seconds between TTS events")
    ap.add_argument("--predict-every", type=int, default=2, help="Run model every N frames")
    args = ap.parse_args()

    model_path = Path("model/model.pkl")
    labels_path = Path("model/labels.json")
    if not model_path.exists() or not labels_path.exists():
        raise FileNotFoundError("Model not found. Run train_model.py first.")

    clf = joblib.load(model_path)
    labels = json.loads(labels_path.read_text())

    mp_hands = mp.solutions.hands
    mp_drawing = mp.solutions.drawing_utils
    mp_styles = mp.solutions.drawing_styles

    cap = cv2.VideoCapture(args.camera_index)
    if not cap.isOpened():
        raise RuntimeError("Could not open camera. Try --camera-index.")

    engine = pyttsx3.init()
    last_spoken = ""
    last_spoken_time = 0.0

    pred_buffer = deque(maxlen=args.smoothing)
    conf_buffer = deque(maxlen=args.smoothing)
    frame_count = 0

    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        min_detection_confidence=0.6,
        min_tracking_confidence=0.6
    ) as hands:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb)

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    mp_drawing.draw_landmarks(
                        frame,
                        hand_landmarks,
                        mp_hands.HAND_CONNECTIONS,
                        mp_styles.get_default_hand_landmarks_style(),
                        mp_styles.get_default_hand_connections_style(),
                    )

            lm = extract_landmarks(results)
            pred_label = None
            pred_conf = 0.0

            # Predict every N frames to reduce jitter
            if lm is not None and (frame_count % max(1, args.predict_every) == 0):
                vec = normalize_landmarks(lm)
                if vec is not None:
                    probs = None
                    if hasattr(clf, "predict_proba"):
                        probs = clf.predict_proba([vec])[0]
                        idx = int(np.argmax(probs))
                        pred_label = clf.classes_[idx]
                        pred_conf = float(probs[idx])
                    else:
                        pred_label = clf.predict([vec])[0]
                        pred_conf = 1.0  # unknown prob for non-proba models

            frame_count += 1

            if pred_label:
                pred_buffer.append(pred_label)
                conf_buffer.append(pred_conf)

            stable = majority_vote(list(pred_buffer))
            avg_conf = float(np.mean(conf_buffer)) if conf_buffer else 0.0

            # Draw overlay
            h, w, _ = frame.shape
            cv2.rectangle(frame, (0,0), (w, 70), (0,0,0), -1)
            txt = f"PRED: {stable if stable else '-'}   CONF: {avg_conf:.2f}"
            cv2.putText(frame, txt, (10, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255,255,255), 2)

            # Speak when stable and changed, with min interval
            now = time.time()
            if stable and avg_conf >= 0.6 and stable != last_spoken and (now - last_spoken_time) > args.speak_interval:
                try:
                    engine.say(stable)
                    engine.runAndWait()
                    last_spoken = stable
                    last_spoken_time = now
                except Exception as e:
                    # Non-fatal if TTS fails
                    print("TTS error:", e)

            cv2.imshow("Sign Language Detection - Press Q to quit", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
