import numpy as np
from typing import Optional, Tuple, List

def normalize_landmarks(landmarks: np.ndarray) -> np.ndarray:
    """
    landmarks: shape (21, 3) -> (x,y,z) in [0,1] from MediaPipe
    Returns a flattened, translation & scale-invariant vector of length 63.
    - Translate so wrist (index 0) is origin.
    - Scale by the distance between wrist (0) and middle fingertip (12) to reduce size variance.
    - Clip extreme values to a safe range.
    """
    if landmarks is None or landmarks.shape != (21, 3):
        return None
    lm = landmarks.copy()
    wrist = lm[0]
    lm = lm - wrist  # translate
    # scale by wrist->middle_finger_tip distance
    ref = lm[12]
    scale = np.linalg.norm(ref) + 1e-6
    lm = lm / scale
    lm = np.clip(lm, -3.0, 3.0)
    return lm.flatten()

def majority_vote(labels: List[str]) -> Optional[str]:
    if not labels:
        return None
    from collections import Counter
    c = Counter(labels)
    return c.most_common(1)[0][0]
