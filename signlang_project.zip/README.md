
# Sign Language Detection (Landmark + ML)

A simple, local, camera-based sign/gesture recognizer using **MediaPipe Hands** for landmarks,
**scikit-learn** for classification, **OpenCV** for video, and **pyttsx3** for text-to-speech.

Works offline. You collect your own gestures, train a model, then run real-time inference.

## 1) Install
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate

pip install -r requirements.txt
```

## 2) Collect data
Run once **per label** you want to recognize, e.g. "HELLO", "YES", "NO", "A", "B".

```bash
python collect_data.py --label HELLO --num-samples 300
python collect_data.py --label YES --num-samples 300
python collect_data.py --label NO --num-samples 300
# add more labels similarly
```

Tips while collecting:
- Keep your hand inside the camera frame; vary **distance, rotation, lighting, and background**.
- Hold the gesture steady; the script samples when a valid hand is detected.
- You can re-run later to add more samples for any label.

All samples are appended to: `data/sign_landmarks.csv`

## 3) Train
```bash
python train_model.py
```
This creates `model/model.pkl` and `model/labels.json`. It also prints a test accuracy.

## 4) Run real-time app
```bash
python run_app.py
```
- Press **Q** to quit.
- The overlay shows the **predicted label** and **confidence**.
- When a label stays stable, the app **speaks** it using text-to-speech.

## Common issues
- If camera fails to open, try `--camera-index` in each script.
- If you get TTS errors on Linux, install `espeak` or try another TTS engine.
- Accuracy low? Collect **more diverse samples**, and add **more labels** evenly.
