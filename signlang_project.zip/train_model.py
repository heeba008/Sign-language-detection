import json
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import joblib

def main():
    data_path = Path("data/sign_landmarks.csv")
    if not data_path.exists():
        raise FileNotFoundError("Data file not found. Run collect_data.py first.")

    df = pd.read_csv(data_path)
    X = df.drop(columns=["label"]).values.astype(np.float32)
    y = df["label"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(
        n_estimators=400, max_depth=None, n_jobs=-1, random_state=42
    )
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Test Accuracy: {acc:.3f}")
    print(classification_report(y_test, y_pred))

    # Save model + labels
    model_dir = Path("model")
    model_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(clf, model_dir / "model.pkl")
    labels = sorted(list(set(y)))
    (model_dir / "labels.json").write_text(json.dumps(labels, indent=2))

    # Optional: print confusion matrix
    print("Confusion Matrix:")
    print(confusion_matrix(y_test, y_pred, labels=labels))

if __name__ == "__main__":
    main()
