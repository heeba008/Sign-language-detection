import argparse, os
import cv2
import numpy as np
import pandas as pd
import mediapipe as mp
from pathlib import Path
from utils import normalize_landmarks

def extract_landmarks(results):
    if not results.multi_hand_landmarks:
        return None
    # Use the first detected hand
    hand_landmarks = results.multi_hand_landmarks[0]
    lm = []
    for lm_pt in hand_landmarks.landmark:
        lm.append([lm_pt.x, lm_pt.y, lm_pt.z])
    return np.array(lm, dtype=np.float32)  # shape (21,3)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--label", required=True, help="Gesture label to record, e.g., HELLO")
    ap.add_argument("--num-samples", type=int, default=300, help="Number of samples to capture")
    ap.add_argument("--camera-index", type=int, default=0, help="cv2.VideoCapture index")
    args = ap.parse_args()

    data_dir = Path("data")
    data_dir.mkdir(parents=True, exist_ok=True)
    csv_path = data_dir / "sign_landmarks.csv"

    mp_hands = mp.solutions.hands
    mp_drawing = mp.solutions.drawing_utils
    mp_styles = mp.solutions.drawing_styles

    cap = cv2.VideoCapture(args.camera_index)
    if not cap.isOpened():
        raise RuntimeError("Could not open camera. Try --camera-index.")

    samples_collected = 0
    header_written = csv_path.exists()

    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        min_detection_confidence=0.6,
        min_tracking_confidence=0.6
    ) as hands:

        while True:
            ret, frame = cap.read()
            if not ret:
                break
            frame = cv2.flip(frame, 1)  # mirror view
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb)

            h, w, _ = frame.shape
            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    mp_drawing.draw_landmarks(
                        frame,
                        hand_landmarks,
                        mp_hands.HAND_CONNECTIONS,
                        mp_styles.get_default_hand_landmarks_style(),
                        mp_styles.get_default_hand_connections_style(),
                    )

            lm = extract_landmarks(results)
            norm = normalize_landmarks(lm) if lm is not None else None

            # Display instructions
            cv2.putText(frame, f"Label: {args.label}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)
            cv2.putText(frame, f"Collected: {samples_collected}/{args.num_samples}", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)
            cv2.putText(frame, "Hold gesture steady. Press Q to quit.", (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 1)

            # Auto-sample when a valid hand is present
            if norm is not None and samples_collected < args.num_samples:
                row = [args.label] + norm.tolist()
                df = pd.DataFrame([row])
                if not header_written:
                    cols = ["label"] + [f"f{i}" for i in range(len(norm))]
                    df.columns = cols
                    df.to_csv(csv_path, index=False, mode="w")
                    header_written = True
                else:
                    df.to_csv(csv_path, index=False, header=False, mode="a")
                samples_collected += 1

            cv2.imshow("Collect Data - Press Q to quit", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q') or samples_collected >= args.num_samples:
                break

    cap.release()
    cv2.destroyAllWindows()
    print(f"Saved to {csv_path}. Total samples now: {sum(1 for _ in open(csv_path)) - 1}")

if __name__ == "__main__":
    main()
